package vn.taksak.bo_sung_cac_truy_van_su_dung_StreamAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoSungCacTruyVanSuDungStreamApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(BoSungCacTruyVanSuDungStreamApiApplication.class, args);
	}

}
